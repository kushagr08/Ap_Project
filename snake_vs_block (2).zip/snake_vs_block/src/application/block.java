package application;
import javafx.application.Application;
import javafx.scene.image.*;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.canvas.*;
import javafx.scene.paint.Color;
import javafx.scene.*;
import javafx.scene.shape.*;
import javafx.animation.Animation.*;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import java.util.*;
import javafx.scene.text.*;
import javafx.scene.control.*;

public class block extends Rectangle  {
      private int value;
      private Text p;
      
      
      public block(int value,Color color,int xcoord,int ycoord,int width,int height) {
    	  super(xcoord,ycoord,width,height);
    	  this.value=value;
    	  this.p=new Text(Integer.toString(value));
			this.p.setX(xcoord+25);
			this.p.setY(ycoord+25);
			this.p.setFill(Color.GREEN);
			
			this.p.setStyle("-fx-color: green");
		 // p.setFill(Color.BLACK);
		  
		  //p.setStyle("-fx-color: green");
		  
		  
		  
		  
		  
    	  
    	  
    	  
    	  
    	  
    	  
      }
      
      public Text gettex() {
    	  return this.p;
      }
      
      
      
      

}
